
Trabajo Práctico Final – Ingeniería de Software II – LCIK

Integrantes:

-Laura Salinas C.I. 5052751
-Mirna Rodriguez C.I. 5012672
-Nilda Panderi C.I. 4313188

Github:

https://github.com/larak92/Miaplicacion.git

Version minima de Android soportada:

minSdkVersion(API Level): 15
Nombre: Ice Cream Sandwich
Versión: 4.0–4.0.4

Instrucciones de uso:
En la primera vista, debe seleccionar un cliente donde se mostraran la direccion y el telefono, mientras
no seleccione alguno, no podra pasar a la siguiente vista.
En la segunda vista, debe seleccionar un producto una cantidad y agregar el pedido, ademas podra
agregar otro pedido o pasar a la siguiente vista.
Observaciones:
1. No selecciono nada, no podra agregar el pedido ni pasar a la siguiente vista.
2. Al seleccionar un producto pero no la cantidad, no podra agregar el pedido ni pasar a la siguiente vista.
3. Al seleccionar un producto y la cantidad pero no agregar, no podra pasar a la siguiente vista.
4. Al seleccionar un producto, la cantidad y agregar, el selector vuelve a su valor por defecto (sin seleccion) y la cantidad (cero).
5. Al agregar un producto se podra realizar otro pedido o pasar a la siguiente vista.
En la tercera vista, podra visualizar el detalle de los pedidos asi como el monto total a pagar. El boton atras
pasa a a segunda vista para realizar otro pedido mas y el boton finalizar pasa a la primera vista de seleccion de clientes.
